let version = "1.81"
let date = "Mon Oct 17 16:27:03 CEST 2011"
